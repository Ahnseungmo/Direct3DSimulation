#include "Framework.h"
#include "EventManager.h"

EventManager::EventManager()
{
}

EventManager::~EventManager()
{
}
